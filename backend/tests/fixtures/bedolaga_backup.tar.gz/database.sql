--
-- PostgreSQL database dump
--

-- Dumped from database version 16.2
-- Dumped by pg_dump version 16.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: subscriptions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.subscriptions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    status character varying(20),
    is_trial boolean DEFAULT true,
    start_date timestamp with time zone,
    end_date timestamp with time zone NOT NULL,
    subscription_url character varying,
    device_limit integer,
    connected_squads json,
    remnawave_short_uuid character varying(255),
    remnawave_id bigint,
    remnawave_uuid character varying(255),
    tariff_id integer
);


--
-- Name: subscriptions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.subscriptions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: subscriptions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.subscriptions_id_seq OWNED BY public.subscriptions.id;


--
-- Name: tariffs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tariffs (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    period_prices json DEFAULT '{}'::json NOT NULL
);


--
-- Name: tariffs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.tariffs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tariffs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.tariffs_id_seq OWNED BY public.tariffs.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    telegram_id bigint,
    auth_type character varying(20) DEFAULT 'telegram'::character varying,
    username character varying(255),
    first_name character varying(255),
    last_name character varying(255),
    status character varying(20) DEFAULT 'active'::character varying,
    language character varying(5) DEFAULT 'ru'::character varying,
    balance_kopeks integer DEFAULT 0,
    has_had_paid_subscription boolean DEFAULT false NOT NULL,
    referred_by_id integer,
    referral_code character varying(20),
    created_at timestamp with time zone DEFAULT now(),
    last_activity timestamp with time zone DEFAULT now(),
    remnawave_id bigint,
    remnawave_uuid character varying(255),
    email character varying(255),
    notification_settings jsonb
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: subscriptions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscriptions ALTER COLUMN id SET DEFAULT nextval('public.subscriptions_id_seq'::regclass);


--
-- Name: tariffs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tariffs ALTER COLUMN id SET DEFAULT nextval('public.tariffs_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: subscriptions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.subscriptions (id, user_id, status, is_trial, start_date, end_date, subscription_url, device_limit, connected_squads, remnawave_short_uuid, remnawave_id, remnawave_uuid, tariff_id) FROM stdin;
1	1	active	f	\N	2027-01-01 03:59:59+04	https://sub.example/alice	\N	\N	aliceShort	501	historic-uuid	2
2	2	trial	t	\N	2026-01-01 04:00:00+04	https://sub.example/bob	\N	\N	\N	502	\N	\N
3	6	active	f	\N	2027-06-01 01:00:00+04	\N	\N	\N	\N	\N	\N	\N
\.


--
-- Data for Name: tariffs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tariffs (id, name, period_prices) FROM stdin;
1	Стандарт	{}
2	Премиум 🚀	{}
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, telegram_id, auth_type, username, first_name, last_name, status, language, balance_kopeks, has_had_paid_subscription, referred_by_id, referral_code, created_at, last_activity, remnawave_id, remnawave_uuid, email, notification_settings) FROM stdin;
1	1001	telegram	alice	Алиса\tтаб	\N	active	ru	15050	t	\N	refAbC12345	2025-03-01 09:00:00+04	2026-10-06 13:11:24.818705+04	\N	\N	\N	{"a": "x\\\\y"}
2	1002	telegram	\N	Боб\nс переносом	\N	active	ru	0	f	1	refXyZ98765	2026-10-06 13:11:24.819228+04	2026-10-06 13:11:24.819228+04	\N	\N	\N	\N
3	1003	telegram	blocked_guy	\N	\N	blocked	ru	999	f	2	\N	2026-10-06 13:11:24.819504+04	2026-10-06 13:11:24.819504+04	\N	\N	\N	\N
4	1004	telegram	gone	\N	\N	deleted	ru	500	f	\N	\N	2026-10-06 13:11:24.819577+04	2026-10-06 13:11:24.819577+04	\N	\N	\N	\N
5	\N	email	\N	\N	\N	active	ru	700	f	\N	\N	2026-10-06 13:11:24.819629+04	2026-10-06 13:11:24.819629+04	\N	\N	web@example.com	\N
6	1006	telegram	legacy	\N	\N	active	ru	0	f	\N	\N	2026-10-06 13:11:24.819681+04	2026-10-06 13:11:24.819681+04	\N	0b6c2f8e-1111-2222-3333-444455556666	\N	\N
\.


--
-- Name: subscriptions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.subscriptions_id_seq', 3, true);


--
-- Name: tariffs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.tariffs_id_seq', 2, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 6, true);


--
-- Name: subscriptions subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_pkey PRIMARY KEY (id);


--
-- Name: tariffs tariffs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tariffs
    ADD CONSTRAINT tariffs_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_referral_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_referral_code_key UNIQUE (referral_code);


--
-- Name: users users_telegram_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_telegram_id_key UNIQUE (telegram_id);


--
-- Name: subscriptions subscriptions_tariff_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_tariff_id_fkey FOREIGN KEY (tariff_id) REFERENCES public.tariffs(id);


--
-- Name: subscriptions subscriptions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: users users_referred_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_referred_by_id_fkey FOREIGN KEY (referred_by_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

